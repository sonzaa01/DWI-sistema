function adicionarRecurso() {
    const div = document.getElementById("recursos");
    const input = document.createElement("input");
    input.type = "text";
    input.placeholder = "Digite um recurso";
    div.appendChild(input);
}

function iniciarFormulario() {
    const form = document.getElementById("formTarefa");

    form.addEventListener("submit", function(e) {
        e.preventDefault();

        const prioridade = document.getElementById("prioridade").value;
        const descricao = document.getElementById("descricao").value;
        const local = document.getElementById("local").value;
        const dataLimite = document.getElementById("dataLimite").value;
        const matricula = document.getElementById("matricula").value;

        if (!prioridade || !descricao || !local || !dataLimite || !matricula) {
            alert("Preencha todos os campos obrigatórios.");
            return;
        }

        const recursosInputs = document.querySelectorAll("#recursos input");
        const recursos = [];

        recursosInputs.forEach(r => {
            if (r.value.trim() !== "") {
                recursos.push(r.value.trim());
            }
        });

        const tarefa = {
            prioridade,
            descricao,
            local,
            recursosNecessarios: recursos,
            dataLimite,
            matricula: Number(matricula)
        };

        const lista = JSON.parse(localStorage.getItem("tarefas")) || [];
        lista.push(tarefa);
        localStorage.setItem("tarefas", JSON.stringify(lista));

        alert("Tarefa cadastrada com sucesso!");
        window.location.href = "index.html";
    });
}

function carregarTarefas() {
    const divLista = document.getElementById("lista");
    const tarefas = JSON.parse(localStorage.getItem("tarefas")) || [];

    if (tarefas.length === 0) {
        divLista.innerHTML = "<p>Nenhuma tarefa cadastrada.</p>";
        return;
    }

    tarefas.forEach(t => {
        const bloco = document.createElement("div");
        bloco.className = "tarefa";

        bloco.innerHTML = `
            <p><strong>Descrição:</strong> ${t.descricao}</p>
            <p><strong>Prioridade:</strong> ${t.prioridade}</p>
            <p><strong>Local:</strong> ${t.local}</p>
            <p><strong>Data limite:</strong> ${t.dataLimite}</p>
            <p><strong>Matrícula:</strong> ${t.matricula}</p>
            <p><strong>Recursos:</strong> ${t.recursosNecessarios.join(", ")}</p>
        `;

        divLista.appendChild(bloco);
    });
}
